﻿**Atchyutuni Sri Dutta Akhil    ![](Aspose.Words.e4ad6769-507c-45dd-8e9e-f3ba89536556.001.png)**#B-105, Prism Sovereign Apartment,  

12th Cross, BEML Layout,   Kundalahalli, Bangalore - 560066  Email ID: atsr18me@cmrit.ac.in  Mobile No: +91 9986554988 

**CAREER OBJECTIVE** 

Seeking an opportunity to utilize my skills, abilities, talent and knowledge in technical area that offers professional growth while being innovative which increases the success with organisation growth. 

**EDUCATION QUALIFICATION** 

- **Bachelor of Engineering – Mechanical**  

CMR Institute of Technology, Bangalore 7.8 CGPA, 2021(Pursuing)**  

- **XII Class** 

Nehru Smaraka Vidyalaya, Jayanagar, Bangalore, Karnataka 

75%, 2018** 

- **X Class**  

Ryan International School, Kundalahalli, Bangalore 82%, 2016** 

**Technical Skills** 

- Languages: C (Intermediate), JAVA (Intermediate) 
- Software: SolidEdge, Ansys2019 

**Co-Curricular Activities & Extra-Curricular Activities Extra – Curricular Activities:** 

- Part of the CMRIT cricket and football team 
- Part of the Cricket team which participated in Bangalore inter-school championships in 2015-16 (runners-up) 

**PERSONAL DETAILS** 

- Date of Birth                           : 18.05.2000 
- Gender : Male 
- Nationality : Indian 
- Marital Status : Single 
- Languages Known : English, Telugu, Kannada, Hindi 
- Hobbies                                   : Playing Cricket / Soccer and Listening to Music 

**Reference** 

- Dr. B. Rajendra Prasad Reddy 

Professor and Hod, Dept of Mechanical Engineering rajendrapradad@cmrit.ac.in 

9986627939 

- Laksham Malla  

Placement director  

Email ID :[ director.placement@cmrit.ac.in ](mailto:director.placement@cmrit.ac.in)

Phone No: +91 9845027392 
